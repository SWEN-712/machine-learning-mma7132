# Databricks notebook source
from tweepy import OAuthHandler
from tweepy import API
from tweepy import Cursor
from textblob import TextBlob
import re

tweet_count = 600
include_retweets = False
t_mode = "extended"
consumer_key = "cKyQiUmKwzXG1m5NcZmAMQ2MB" #twitter app’s API Key
consumer_secret = "uZjTwaVk72p1lnJ1MbW7BYPxtuIbpkH3yO5K2sUsXIIKmAKunZ" #twitter app’s API secret Key
access_token = "1238986541999034369-wXo7zk0bMZekpYYdMlcYtpGV9kB4yY" #twitter app’s Access token
access_token_secret = "uBuVDZlVgCHrNxjGYpKC31ZKgQZKIDYdKVKxeVBhd2Nke" #twitter app’s access token secret

def clean_tweet(tweet): 
  ''' 
  Utility function to clean tweet text by removing links, special characters 
  using simple regex statements. 
  '''
  return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split()) 
  
def get_tweet_sentiment(tweet): 
  ''' 
  Utility function to classify sentiment of passed tweet 
  using textblob's sentiment method 
  '''
  # create TextBlob object of passed tweet text 
  analysis = TextBlob(clean_tweet(tweet)) 
  # set sentiment 
  return analysis.sentiment.polarity
  if analysis.sentiment.polarity > 0: 
    return 'positive'
  elif analysis.sentiment.polarity == 0: 
    return 'neutral'
  else: 
    return 'negative' 
                               
                               


auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
auth_api = API(auth)

trump_tweets = auth_api.user_timeline(screen_name = 'realDonaldTrump', count = tweet_count, include_rts = include_retweets, tweet_mode = t_mode)

final_tweets = [each_tweet.full_text for each_tweet in trump_tweets]

with open('trump_tweets.txt', 'w') as f:
  for item in final_tweets:
    f.write("%s\n" % item)
          
read_tweets = []
with open('trump_tweets.txt','r') as f:
  read_tweets.append(f.read())
  
read_tweets = read_tweets[0].split("\n")
total_sentiment = 0.00
max_sentiment = 0
min_sentiment = 0
for e in read_tweets:
  t = clean_tweet(e)
  if get_tweet_sentiment(t) > max_sentiment:
    max_sentiment = get_tweet_sentiment(t)
  if get_tweet_sentiment(t) < min_sentiment:
    min_sentiment = get_tweet_sentiment(t)
  total_sentiment+=get_tweet_sentiment(t)
  
print("Total tweets: " + str(len(read_tweets)))
print("Minimum sentiment: " + str(min_sentiment))
print("Maximum sentiment: " + str(max_sentiment))
print("Average sentiment: " + str(total_sentiment/len(read_tweets)))

  
  

  

# COMMAND ----------



